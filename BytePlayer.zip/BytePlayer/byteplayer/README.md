# BytePlayer
Reproductor multimedia multiplataforma · Creado por BYTE A BYTE.

Flutter + media_kit (libmpv) + yt-dlp · Clean Architecture · UI SamEntertainment + LiquidGlass.

## Primer uso
1. Sube todo a GitHub (rama `main`). El workflow genera `windows/` y `linux/` si faltan y compila.
2. En local: `flutter create --platforms=windows,linux,android --project-name byteplayer --org com.byteabyte .` (solo una vez, no pisa `lib/`) y luego `flutter pub get && flutter run -d windows`.
3. Rellena tus datos en `lib/core/constants/app_constants.dart` (YouTube y correo).

## yt-dlp
Se busca en: ruta de Ajustes > Red, junto al ejecutable, y en el PATH. El workflow lo incluye en las compilaciones.
Para mezclar video+audio o extraer MP3 necesita `ffmpeg` en el PATH.

## Estructura
```
lib/
  core/        constantes, tema, widgets de cristal, DI, utilidades
  features/
    home/ about/ settings/ player/ downloads/
      domain/        entidades, contratos, casos de uso
      data/          implementaciones (media_kit, yt-dlp, SharedPreferences)
      presentation/  pantallas y controladores (Riverpod)
```
