import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:media_kit/media_kit.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'app.dart';
import 'core/di/providers.dart';
import 'core/platform/window_effects.dart';
import 'features/settings/data/settings_repository_impl.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  MediaKit.ensureInitialized();

  final prefs = await SharedPreferences.getInstance();
  final settings = SharedPrefsSettingsRepository(prefs).load();

  await WindowEffects.init();
  if (settings.acrylic) await WindowEffects.apply(true);

  runApp(
    ProviderScope(
      overrides: [sharedPrefsProvider.overrideWithValue(prefs)],
      child: const BytePlayerApp(),
    ),
  );
}
