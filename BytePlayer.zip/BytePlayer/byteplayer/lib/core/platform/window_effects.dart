import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_acrylic/flutter_acrylic.dart';

class WindowEffects {
  WindowEffects._();

  static bool get supported => Platform.isWindows || Platform.isLinux || Platform.isMacOS;

  static Future<void> init() async {
    if (!supported) return;
    try {
      await Window.initialize();
    } catch (_) {}
  }

  static Future<void> apply(bool enabled) async {
    if (!supported) return;
    try {
      final effect = !enabled
          ? WindowEffect.disabled
          : Platform.isWindows
              ? WindowEffect.acrylic
              : Platform.isMacOS
                  ? WindowEffect.hudWindow
                  : WindowEffect.transparent;
      await Window.setEffect(effect: effect, color: const Color(0xCC0A0E17), dark: true);
    } catch (_) {}
  }
}
