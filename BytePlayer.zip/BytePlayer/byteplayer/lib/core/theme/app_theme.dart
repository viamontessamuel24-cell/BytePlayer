import 'package:flutter/material.dart';

class AppColors {
  AppColors._();
  static const bg = Color(0xFF0A0E17);
  static const surface = Color(0xFF121826);
  static const red = Color(0xFFE50914);
  static const redDark = Color(0xFFB20710);
  static const success = Color(0xFF2ECC71);
}

enum AppThemeVariant {
  dark('Oscuro'),
  amoled('AMOLED'),
  light('Claro');

  const AppThemeVariant(this.label);
  final String label;
}

class AppTheme {
  AppTheme._();

  static Color background(AppThemeVariant v) {
    switch (v) {
      case AppThemeVariant.dark:
        return AppColors.bg;
      case AppThemeVariant.amoled:
        return Colors.black;
      case AppThemeVariant.light:
        return const Color(0xFFF2F4F8);
    }
  }

  static ThemeData build(AppThemeVariant v) {
    final light = v == AppThemeVariant.light;
    final base = light ? ThemeData.light(useMaterial3: true) : ThemeData.dark(useMaterial3: true);
    final scheme = (light ? const ColorScheme.light() : const ColorScheme.dark()).copyWith(
      primary: AppColors.red,
      secondary: AppColors.red,
    );
    return base.copyWith(
      colorScheme: scheme,
      scaffoldBackgroundColor: Colors.transparent,
      canvasColor: Colors.transparent,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
      ),
      sliderTheme: SliderThemeData(
        activeTrackColor: AppColors.red,
        thumbColor: AppColors.red,
        inactiveTrackColor: (light ? Colors.black : Colors.white).withOpacity(0.18),
        overlayColor: AppColors.red.withOpacity(0.2),
        trackHeight: 3.5,
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith(
            (s) => s.contains(WidgetState.selected) ? Colors.white : Colors.grey),
        trackColor: WidgetStateProperty.resolveWith(
            (s) => s.contains(WidgetState.selected) ? AppColors.red : Colors.white24),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: AppColors.surface,
        contentTextStyle: const TextStyle(color: Colors.white),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }
}
