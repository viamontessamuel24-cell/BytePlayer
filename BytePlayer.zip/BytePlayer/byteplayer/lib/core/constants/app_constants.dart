class AppConstants {
  AppConstants._();

  static const appName = 'BytePlayer';
  static const creditText = 'Creado por BYTE A BYTE';

  // ====== RELLENA ESTOS CAMPOS ======
  static const youtubeUrl = 'https://youtube.com/@bytebytecu';
  static const contactEmail = 'samuelviamontes07@gmail.com';
  static const emailSubject = 'Contacto desde BytePlayer';
  // ==================================

  static const audioExtensions = {
    'mp3', 'flac', 'wav', 'ogg', 'opus', 'm4a', 'aac', 'wma', 'aiff',
  };
  static const videoExtensions = {
    'mp4', 'mkv', 'avi', 'mov', 'webm', 'flv', 'wmv', 'ts', 'm4v', 'mpg', 'mpeg', '3gp',
  };
}
