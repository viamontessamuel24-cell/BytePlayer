import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../features/settings/presentation/settings_controller.dart';
import '../theme/app_theme.dart';

/// Fondo global: color base + resplandores rojos para que el cristal tenga qué desenfocar.
class AppBackground extends ConsumerWidget {
  const AppBackground({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(settingsProvider);
    final base = AppTheme.background(s.theme);
    final alpha = s.acrylic ? 0.55 : 1.0;
    final light = s.theme == AppThemeVariant.light;

    return Stack(
      children: [
        Positioned.fill(child: ColoredBox(color: base.withOpacity(alpha))),
        if (s.theme != AppThemeVariant.amoled) ...[
          Positioned(
            top: -150,
            left: -120,
            child: _Blob(color: AppColors.red.withOpacity(light ? 0.16 : 0.28), size: 420),
          ),
          Positioned(
            bottom: -180,
            right: -140,
            child: _Blob(color: AppColors.red.withOpacity(light ? 0.12 : 0.20), size: 480),
          ),
        ],
        Positioned.fill(child: child),
      ],
    );
  }
}

class _Blob extends StatelessWidget {
  const _Blob({required this.color, required this.size});
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [color, color.withOpacity(0)]),
        ),
      ),
    );
  }
}
