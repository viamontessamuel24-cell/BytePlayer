import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Efecto "LiquidGlass": desenfoque + degradado translúcido + borde luminoso.
class GlassContainer extends StatelessWidget {
  const GlassContainer({
    super.key,
    required this.child,
    this.borderRadius = 24,
    this.blur = 22,
    this.padding = const EdgeInsets.all(16),
    this.glow = false,
    this.opacity = 0.10,
  });

  final Widget child;
  final double borderRadius;
  final double blur;
  final EdgeInsetsGeometry padding;
  final bool glow;
  final double opacity;

  @override
  Widget build(BuildContext context) {
    final light = Theme.of(context).brightness == Brightness.light;
    final o = light ? 0.55 : opacity;
    final radius = BorderRadius.circular(borderRadius);

    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: radius,
        boxShadow: [
          BoxShadow(
            color: glow ? AppColors.red.withOpacity(0.35) : Colors.black.withOpacity(0.22),
            blurRadius: glow ? 32 : 20,
            spreadRadius: glow ? 1 : 0,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: radius,
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
          child: Container(
            padding: padding,
            decoration: BoxDecoration(
              borderRadius: radius,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.white.withOpacity(o + 0.08),
                  Colors.white.withOpacity(o * 0.4),
                ],
              ),
              border: Border.all(color: Colors.white.withOpacity(0.22), width: 1.1),
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}
