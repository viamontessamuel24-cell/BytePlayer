import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class GlowButton extends StatelessWidget {
  const GlowButton({
    super.key,
    required this.label,
    required this.icon,
    required this.onPressed,
    this.primary = true,
    this.expanded = false,
  });

  final String label;
  final IconData icon;
  final VoidCallback? onPressed;
  final bool primary;
  final bool expanded;

  @override
  Widget build(BuildContext context) {
    final fg = primary ? Colors.white : Theme.of(context).colorScheme.onSurface;
    final content = Row(
      mainAxisSize: expanded ? MainAxisSize.max : MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: fg, size: 20),
        const SizedBox(width: 10),
        Flexible(
          child: Text(label,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: fg, fontWeight: FontWeight.w600, fontSize: 15)),
        ),
      ],
    );

    return Opacity(
      opacity: onPressed == null ? 0.5 : 1,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: primary
              ? const LinearGradient(colors: [AppColors.red, AppColors.redDark])
              : null,
          color: primary ? null : Colors.white.withOpacity(0.08),
          border: primary ? null : Border.all(color: Colors.white.withOpacity(0.2)),
          boxShadow: primary
              ? [BoxShadow(color: AppColors.red.withOpacity(0.55), blurRadius: 24, spreadRadius: 1)]
              : null,
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: onPressed,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
              child: content,
            ),
          ),
        ),
      ),
    );
  }
}
