import '../constants/app_constants.dart';

bool isAudioSource(String source) {
  final clean = source.split('?').first;
  final dot = clean.lastIndexOf('.');
  if (dot < 0) return false;
  return AppConstants.audioExtensions.contains(clean.substring(dot + 1).toLowerCase());
}

String formatDuration(Duration d) {
  final h = d.inHours;
  final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
  final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  return h > 0 ? '$h:$m:$s' : '$m:$s';
}

String fileNameOf(String path) {
  final parts = path.split(RegExp(r'[\\/]'));
  return parts.isEmpty ? path : parts.last;
}
