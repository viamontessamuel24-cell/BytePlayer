import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/di/providers.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/media_utils.dart';
import '../../../core/widgets/glass_container.dart';
import '../../../core/widgets/glow_button.dart';
import '../../about/presentation/about_screen.dart';
import '../../downloads/presentation/downloads_screen.dart';
import '../../player/presentation/player_screen.dart';
import '../../settings/presentation/settings_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  void _push(BuildContext context, Widget page) =>
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));

  Future<void> _openFile(BuildContext context) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: [
        ...AppConstants.videoExtensions,
        ...AppConstants.audioExtensions,
      ],
    );
    final path = result?.files.single.path;
    if (path == null || !context.mounted) return;
    _push(context, PlayerScreen(source: path, title: fileNameOf(path), isAudio: isAudioSource(path)));
  }

  Future<void> _openUrl(BuildContext context) async {
    final ctrl = TextEditingController();
    final url = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        title: const Text('Reproducir desde enlace'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'https://...'),
          onSubmitted: (v) => Navigator.pop(ctx, v),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancelar')),
          TextButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('Reproducir')),
        ],
      ),
    );
    ctrl.dispose();
    final u = url?.trim() ?? '';
    if (u.isEmpty || !context.mounted) return;
    _push(context, PlayerScreen(source: u, title: u, isAudio: isAudioSource(u)));
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final online = ref.watch(connectivityProvider).valueOrNull ?? true;

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 480),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Logo: botón Play rojo con glow
                  Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(34),
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [AppColors.red, AppColors.redDark],
                      ),
                      boxShadow: [
                        BoxShadow(color: AppColors.red.withOpacity(0.6), blurRadius: 50, spreadRadius: 4),
                      ],
                    ),
                    child: const Icon(Icons.play_arrow_rounded, size: 84, color: Colors.white),
                  ),
                  const SizedBox(height: 22),
                  Text(
                    AppConstants.appName,
                    style: Theme.of(context)
                        .textTheme
                        .displaySmall
                        ?.copyWith(fontWeight: FontWeight.w800, letterSpacing: 0.5),
                  ),
                  const SizedBox(height: 12),

                  // Estado de conexión
                  GlassContainer(
                    borderRadius: 30,
                    blur: 14,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.circle, size: 10, color: online ? AppColors.success : AppColors.red),
                        const SizedBox(width: 8),
                        Text(
                          online ? 'Conectado a la nube' : 'Sin conexión',
                          style: TextStyle(
                            color: online ? AppColors.success : AppColors.red,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 32),

                  GlassContainer(
                    glow: true,
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      children: [
                        GlowButton(
                          label: 'Abrir archivo',
                          icon: Icons.folder_open_rounded,
                          expanded: true,
                          onPressed: () => _openFile(context),
                        ),
                        const SizedBox(height: 12),
                        GlowButton(
                          label: 'Reproducir enlace',
                          icon: Icons.link_rounded,
                          primary: false,
                          expanded: true,
                          onPressed: () => _openUrl(context),
                        ),
                        const SizedBox(height: 12),
                        GlowButton(
                          label: 'Descargas',
                          icon: Icons.download_rounded,
                          primary: false,
                          expanded: true,
                          onPressed: () => _push(context, const DownloadsScreen()),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: GlowButton(
                                label: 'Ajustes',
                                icon: Icons.settings_rounded,
                                primary: false,
                                expanded: true,
                                onPressed: () => _push(context, const SettingsScreen()),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: GlowButton(
                                label: 'Acerca de',
                                icon: Icons.info_outline_rounded,
                                primary: false,
                                expanded: true,
                                onPressed: () => _push(context, const AboutScreen()),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
