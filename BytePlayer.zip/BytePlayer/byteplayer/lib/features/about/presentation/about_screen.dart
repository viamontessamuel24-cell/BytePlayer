import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/glass_container.dart';
import '../../../core/widgets/glow_button.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  Future<void> _launch(BuildContext context, Uri uri) async {
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('No se pudo abrir el enlace')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Acerca de')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 440),
            child: GlassContainer(
              glow: true,
              padding: const EdgeInsets.all(28),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 88,
                    height: 88,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(26),
                      gradient: const LinearGradient(colors: [AppColors.red, AppColors.redDark]),
                      boxShadow: [BoxShadow(color: AppColors.red.withOpacity(0.55), blurRadius: 34)],
                    ),
                    child: const Icon(Icons.play_arrow_rounded, size: 62, color: Colors.white),
                  ),
                  const SizedBox(height: 16),
                  Text(AppConstants.appName,
                      style: Theme.of(context)
                          .textTheme
                          .headlineMedium
                          ?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  FutureBuilder<PackageInfo>(
                    future: PackageInfo.fromPlatform(),
                    builder: (_, snap) {
                      final i = snap.data;
                      return Text(
                        i == null ? 'Versión …' : 'Versión ${i.version} (${i.buildNumber})',
                        style: const TextStyle(color: Colors.grey),
                      );
                    },
                  ),
                  const SizedBox(height: 22),
                  const Text(
                    AppConstants.creditText,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, letterSpacing: 1),
                  ),
                  const SizedBox(height: 24),
                  GlowButton(
                    label: 'Canal de YouTube',
                    icon: Icons.smart_display_rounded,
                    expanded: true,
                    onPressed: () => _launch(context, Uri.parse(AppConstants.youtubeUrl)),
                  ),
                  const SizedBox(height: 12),
                  GlowButton(
                    label: 'Enviar correo',
                    icon: Icons.mail_outline_rounded,
                    primary: false,
                    expanded: true,
                    onPressed: () => _launch(
                      context,
                      Uri(
                        scheme: 'mailto',
                        path: AppConstants.contactEmail,
                        queryParameters: {'subject': AppConstants.emailSubject},
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
