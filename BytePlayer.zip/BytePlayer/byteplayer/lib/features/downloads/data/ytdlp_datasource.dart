import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import '../domain/entities/download_task.dart';

class YtDlpMissingException implements Exception {
  @override
  String toString() =>
      'No se encontró yt-dlp. Colócalo junto al ejecutable, añádelo al PATH o indica su ruta en Ajustes > Red.';
}

/// Llama a yt-dlp como proceso nativo y traduce su salida a eventos de progreso.
class YtDlpDataSource {
  final _procs = <String, Process>{};

  static final _pct = RegExp(r'\[download\]\s+([\d.]+)%');
  static final _speed = RegExp(r'at\s+(\S+/s)');
  static final _eta = RegExp(r'ETA\s+([\d:]+)');
  static final _dest = RegExp(r'^\[(?:download|ExtractAudio)\] Destination:\s+(.+)$');
  static final _merge = RegExp(r'^\[Merger\] Merging formats into "(.+)"$');
  static final _already = RegExp(r'^\[download\] (.+) has already been downloaded');

  Future<String> _resolveBinary(String custom) async {
    if (custom.isNotEmpty) return custom;
    final name = Platform.isWindows ? 'yt-dlp.exe' : 'yt-dlp';
    final local = File(p.join(File(Platform.resolvedExecutable).parent.path, name));
    if (await local.exists()) return local.path;
    return name; // se busca en el PATH
  }

  Stream<DownloadProgress> run({
    required String id,
    required String url,
    required DownloadQuality quality,
    required DownloadOptions options,
  }) async* {
    final bin = await _resolveBinary(options.binaryPath);
    final args = <String>[
      '--newline',
      '--no-playlist',
      if (options.forceIpv4) '-4',
      if (options.proxy.isNotEmpty) ...['--proxy', options.proxy],
      ...quality.args,
      '-o',
      p.join(options.outputDir, '%(title).150B [%(id)s].%(ext)s'),
      url,
    ];

    final Process proc;
    try {
      proc = await Process.start(bin, args);
    } on ProcessException {
      throw YtDlpMissingException();
    }
    _procs[id] = proc;

    final err = StringBuffer();
    proc.stderr.transform(const Utf8Decoder(allowMalformed: true)).listen(err.write);

    String? file;
    final lines = proc.stdout
        .transform(const Utf8Decoder(allowMalformed: true))
        .transform(const LineSplitter());

    await for (final line in lines) {
      final d = _dest.firstMatch(line) ?? _merge.firstMatch(line) ?? _already.firstMatch(line);
      if (d != null) file = d.group(1);

      final pc = _pct.firstMatch(line);
      if (pc != null) {
        yield DownloadProgress(
          percent: double.tryParse(pc.group(1)!),
          speed: _speed.firstMatch(line)?.group(1),
          eta: _eta.firstMatch(line)?.group(1),
          filePath: file,
        );
      }
    }

    final code = await proc.exitCode;
    _procs.remove(id);
    if (code != 0) {
      final msg = err.toString().trim();
      throw Exception(msg.isEmpty ? 'yt-dlp terminó con código $code' : msg);
    }
    yield DownloadProgress(percent: 100, filePath: file, done: true);
  }

  void cancel(String id) => _procs.remove(id)?.kill();
}
