import '../domain/entities/download_task.dart';
import '../domain/repositories/download_repository.dart';
import 'ytdlp_datasource.dart';

class DownloadRepositoryImpl implements DownloadRepository {
  DownloadRepositoryImpl(this._ds);
  final YtDlpDataSource _ds;

  @override
  Stream<DownloadProgress> start({
    required String id,
    required String url,
    required DownloadQuality quality,
    required DownloadOptions options,
  }) =>
      _ds.run(id: id, url: url, quality: quality, options: options);

  @override
  void cancel(String id) => _ds.cancel(id);
}
