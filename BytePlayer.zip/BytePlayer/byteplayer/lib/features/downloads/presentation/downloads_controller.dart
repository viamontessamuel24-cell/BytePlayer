import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../../settings/presentation/settings_controller.dart';
import '../data/download_repository_impl.dart';
import '../data/ytdlp_datasource.dart';
import '../domain/entities/download_task.dart';
import '../domain/repositories/download_repository.dart';
import '../domain/usecases/download_usecases.dart';

final _dataSourceProvider = Provider<YtDlpDataSource>((_) => YtDlpDataSource());
final downloadRepositoryProvider =
    Provider<DownloadRepository>((ref) => DownloadRepositoryImpl(ref.watch(_dataSourceProvider)));
final startDownloadProvider =
    Provider((ref) => StartDownload(ref.watch(downloadRepositoryProvider)));
final cancelDownloadProvider =
    Provider((ref) => CancelDownload(ref.watch(downloadRepositoryProvider)));

final downloadsProvider =
    NotifierProvider<DownloadsController, List<DownloadTask>>(DownloadsController.new);

class DownloadsController extends Notifier<List<DownloadTask>> {
  @override
  List<DownloadTask> build() => [];

  void _update(String id, DownloadTask Function(DownloadTask) f) {
    state = [for (final t in state) t.id == id ? f(t) : t];
  }

  Future<String> _outputDir(String custom) async {
    final base = custom.isNotEmpty
        ? custom
        : ((await getDownloadsDirectory()) ?? await getApplicationDocumentsDirectory()).path;
    final dir = custom.isNotEmpty ? base : p.join(base, 'BytePlayer');
    await Directory(dir).create(recursive: true);
    return dir;
  }

  Future<void> add(String url, DownloadQuality quality) async {
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    state = [DownloadTask(id: id, url: url, quality: quality), ...state];

    try {
      final s = ref.read(settingsProvider);
      final opts = DownloadOptions(
        outputDir: await _outputDir(s.downloadDir),
        proxy: s.proxy,
        forceIpv4: s.forceIpv4,
        binaryPath: s.ytDlpPath,
      );
      await for (final e in ref
          .read(startDownloadProvider)
          .call(id: id, url: url, quality: quality, options: opts)) {
        _update(
          id,
          (t) => t.copyWith(
            progress: e.percent,
            speed: e.speed,
            eta: e.eta,
            filePath: e.filePath,
            status: e.done ? DownloadStatus.done : DownloadStatus.running,
          ),
        );
      }
    } catch (e) {
      final cancelled = state.any((t) => t.id == id && t.status == DownloadStatus.cancelled);
      if (cancelled) return;
      _update(
        id,
        (t) => t.copyWith(
          status: DownloadStatus.error,
          error: e.toString().replaceFirst('Exception: ', ''),
        ),
      );
    }
  }

  void cancel(String id) {
    _update(id, (t) => t.copyWith(status: DownloadStatus.cancelled));
    ref.read(cancelDownloadProvider).call(id);
  }

  void remove(String id) => state = state.where((t) => t.id != id).toList();
}
