import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/media_utils.dart';
import '../../../core/widgets/glass_container.dart';
import '../../../core/widgets/glow_button.dart';
import '../../player/presentation/player_screen.dart';
import '../domain/entities/download_task.dart';
import 'downloads_controller.dart';

class DownloadsScreen extends ConsumerStatefulWidget {
  const DownloadsScreen({super.key});

  @override
  ConsumerState<DownloadsScreen> createState() => _DownloadsScreenState();
}

class _DownloadsScreenState extends ConsumerState<DownloadsScreen> {
  final _url = TextEditingController();
  DownloadQuality _quality = DownloadQuality.best;

  @override
  void dispose() {
    _url.dispose();
    super.dispose();
  }

  Future<void> _paste() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text != null) setState(() => _url.text = data!.text!.trim());
  }

  void _start() {
    final url = _url.text.trim();
    if (!url.startsWith('http')) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Pega un enlace válido (http/https)')));
      return;
    }
    ref.read(downloadsProvider.notifier).add(url, _quality);
    _url.clear();
  }

  @override
  Widget build(BuildContext context) {
    final tasks = ref.watch(downloadsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Descargas')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              GlassContainer(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextField(
                      controller: _url,
                      decoration: InputDecoration(
                        hintText: 'Pega aquí la URL del video o audio',
                        prefixIcon: const Icon(Icons.link_rounded),
                        suffixIcon: IconButton(
                          icon: const Icon(Icons.content_paste_rounded),
                          tooltip: 'Pegar',
                          onPressed: _paste,
                        ),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      onSubmitted: (_) => _start(),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: DropdownButtonFormField<DownloadQuality>(
                            value: _quality,
                            decoration: InputDecoration(
                              labelText: 'Calidad',
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                            ),
                            dropdownColor: AppColors.surface,
                            items: DownloadQuality.values
                                .map((q) => DropdownMenuItem(value: q, child: Text(q.label)))
                                .toList(),
                            onChanged: (q) => setState(() => _quality = q ?? _quality),
                          ),
                        ),
                        const SizedBox(width: 12),
                        GlowButton(label: 'Descargar', icon: Icons.download_rounded, onPressed: _start),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              if (tasks.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(32),
                  child: Center(child: Text('Aún no hay descargas', style: TextStyle(color: Colors.grey))),
                ),
              for (final t in tasks)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: _TaskCard(task: t),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TaskCard extends ConsumerWidget {
  const _TaskCard({required this.task});
  final DownloadTask task;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = ref.read(downloadsProvider.notifier);
    final running = task.status == DownloadStatus.running;

    String subtitle;
    switch (task.status) {
      case DownloadStatus.running:
        subtitle = '${task.progress.toStringAsFixed(1)}%  ${task.speed}  ${task.eta.isEmpty ? '' : 'ETA ${task.eta}'}';
        break;
      case DownloadStatus.done:
        subtitle = 'Completado';
        break;
      case DownloadStatus.cancelled:
        subtitle = 'Cancelado';
        break;
      case DownloadStatus.error:
        subtitle = task.error ?? 'Error';
        break;
    }

    return GlassContainer(
      borderRadius: 20,
      glow: running,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            task.filePath != null ? fileNameOf(task.filePath!) : task.url,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 4),
          Text(task.quality.label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
          const SizedBox(height: 8),
          if (running || task.status == DownloadStatus.done)
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: task.progress / 100,
                minHeight: 6,
                color: AppColors.red,
                backgroundColor: Colors.white12,
              ),
            ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            maxLines: 4,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 12,
              color: task.status == DownloadStatus.error ? Colors.redAccent : null,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              if (running)
                TextButton.icon(
                  onPressed: () => c.cancel(task.id),
                  icon: const Icon(Icons.stop_rounded),
                  label: const Text('Cancelar'),
                ),
              if (task.status == DownloadStatus.done && task.filePath != null)
                TextButton.icon(
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                    builder: (_) => PlayerScreen(
                      source: task.filePath!,
                      title: fileNameOf(task.filePath!),
                      isAudio: isAudioSource(task.filePath!),
                    ),
                  )),
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: const Text('Reproducir'),
                ),
              if (!running)
                IconButton(
                  icon: const Icon(Icons.delete_outline_rounded),
                  onPressed: () => c.remove(task.id),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
