import '../entities/download_task.dart';

abstract class DownloadRepository {
  Stream<DownloadProgress> start({
    required String id,
    required String url,
    required DownloadQuality quality,
    required DownloadOptions options,
  });

  void cancel(String id);
}
