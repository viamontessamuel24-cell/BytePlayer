enum DownloadQuality {
  best('Mejor calidad', ['-f', 'bv*+ba/b']),
  p1080('1080p', ['-f', 'bv*[height<=1080]+ba/b[height<=1080]/b']),
  p720('720p', ['-f', 'bv*[height<=720]+ba/b[height<=720]/b']),
  p480('480p', ['-f', 'bv*[height<=480]+ba/b[height<=480]/b']),
  audio('Solo audio (MP3)', ['-x', '--audio-format', 'mp3', '--audio-quality', '0']);

  const DownloadQuality(this.label, this.args);
  final String label;
  final List<String> args;
}

enum DownloadStatus { running, done, error, cancelled }

class DownloadOptions {
  const DownloadOptions({
    required this.outputDir,
    this.proxy = '',
    this.forceIpv4 = false,
    this.binaryPath = '',
  });
  final String outputDir;
  final String proxy;
  final bool forceIpv4;
  final String binaryPath;
}

class DownloadProgress {
  const DownloadProgress({this.percent, this.speed, this.eta, this.filePath, this.done = false});
  final double? percent;
  final String? speed;
  final String? eta;
  final String? filePath;
  final bool done;
}

class DownloadTask {
  const DownloadTask({
    required this.id,
    required this.url,
    required this.quality,
    this.status = DownloadStatus.running,
    this.progress = 0,
    this.speed = '',
    this.eta = '',
    this.filePath,
    this.error,
  });

  final String id;
  final String url;
  final DownloadQuality quality;
  final DownloadStatus status;
  final double progress; // 0..100
  final String speed;
  final String eta;
  final String? filePath;
  final String? error;

  DownloadTask copyWith({
    DownloadStatus? status,
    double? progress,
    String? speed,
    String? eta,
    String? filePath,
    String? error,
  }) =>
      DownloadTask(
        id: id,
        url: url,
        quality: quality,
        status: status ?? this.status,
        progress: progress ?? this.progress,
        speed: speed ?? this.speed,
        eta: eta ?? this.eta,
        filePath: filePath ?? this.filePath,
        error: error ?? this.error,
      );
}
