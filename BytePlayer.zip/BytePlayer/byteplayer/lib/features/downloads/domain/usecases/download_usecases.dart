import '../entities/download_task.dart';
import '../repositories/download_repository.dart';

class StartDownload {
  const StartDownload(this._repo);
  final DownloadRepository _repo;

  Stream<DownloadProgress> call({
    required String id,
    required String url,
    required DownloadQuality quality,
    required DownloadOptions options,
  }) =>
      _repo.start(id: id, url: url, quality: quality, options: options);
}

class CancelDownload {
  const CancelDownload(this._repo);
  final DownloadRepository _repo;

  void call(String id) => _repo.cancel(id);
}
