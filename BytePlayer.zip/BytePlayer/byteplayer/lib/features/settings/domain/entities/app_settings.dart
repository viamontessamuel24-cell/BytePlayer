import '../../../../core/theme/app_theme.dart';

class AppSettings {
  const AppSettings({
    this.autoHideSeconds = 4,
    this.theme = AppThemeVariant.dark,
    this.hardwareDecoding = true,
    this.acrylic = false,
    this.proxy = '',
    this.forceIpv4 = false,
    this.ytDlpPath = '',
    this.downloadDir = '',
  });

  final int autoHideSeconds;
  final AppThemeVariant theme;
  final bool hardwareDecoding;
  final bool acrylic;
  final String proxy;
  final bool forceIpv4;
  final String ytDlpPath;
  final String downloadDir;

  AppSettings copyWith({
    int? autoHideSeconds,
    AppThemeVariant? theme,
    bool? hardwareDecoding,
    bool? acrylic,
    String? proxy,
    bool? forceIpv4,
    String? ytDlpPath,
    String? downloadDir,
  }) =>
      AppSettings(
        autoHideSeconds: autoHideSeconds ?? this.autoHideSeconds,
        theme: theme ?? this.theme,
        hardwareDecoding: hardwareDecoding ?? this.hardwareDecoding,
        acrylic: acrylic ?? this.acrylic,
        proxy: proxy ?? this.proxy,
        forceIpv4: forceIpv4 ?? this.forceIpv4,
        ytDlpPath: ytDlpPath ?? this.ytDlpPath,
        downloadDir: downloadDir ?? this.downloadDir,
      );
}
