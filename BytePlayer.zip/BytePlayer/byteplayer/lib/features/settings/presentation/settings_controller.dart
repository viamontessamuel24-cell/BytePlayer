import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/di/providers.dart';
import '../../../core/platform/window_effects.dart';
import '../../../core/theme/app_theme.dart';
import '../data/settings_repository_impl.dart';
import '../domain/entities/app_settings.dart';
import '../domain/repositories/settings_repository.dart';

final settingsRepositoryProvider = Provider<SettingsRepository>(
  (ref) => SharedPrefsSettingsRepository(ref.watch(sharedPrefsProvider)),
);

final settingsProvider =
    NotifierProvider<SettingsController, AppSettings>(SettingsController.new);

class SettingsController extends Notifier<AppSettings> {
  @override
  AppSettings build() => ref.read(settingsRepositoryProvider).load();

  Future<void> _set(AppSettings s) async {
    state = s;
    await ref.read(settingsRepositoryProvider).save(s);
  }

  Future<void> setAutoHide(int seconds) => _set(state.copyWith(autoHideSeconds: seconds));
  Future<void> setTheme(AppThemeVariant v) => _set(state.copyWith(theme: v));
  Future<void> setHardware(bool v) => _set(state.copyWith(hardwareDecoding: v));
  Future<void> setProxy(String v) => _set(state.copyWith(proxy: v.trim()));
  Future<void> setForceIpv4(bool v) => _set(state.copyWith(forceIpv4: v));
  Future<void> setYtDlpPath(String v) => _set(state.copyWith(ytDlpPath: v.trim()));
  Future<void> setDownloadDir(String v) => _set(state.copyWith(downloadDir: v.trim()));

  Future<void> setAcrylic(bool v) async {
    await _set(state.copyWith(acrylic: v));
    await WindowEffects.apply(v);
  }
}
