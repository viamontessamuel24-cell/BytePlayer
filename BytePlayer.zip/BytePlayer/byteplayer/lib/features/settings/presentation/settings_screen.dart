import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/platform/window_effects.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/glass_container.dart';
import 'settings_controller.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  late final TextEditingController _proxy;
  late final TextEditingController _ytdlp;
  late final TextEditingController _dir;

  @override
  void initState() {
    super.initState();
    final s = ref.read(settingsProvider);
    _proxy = TextEditingController(text: s.proxy);
    _ytdlp = TextEditingController(text: s.ytDlpPath);
    _dir = TextEditingController(text: s.downloadDir);
  }

  @override
  void dispose() {
    _proxy.dispose();
    _ytdlp.dispose();
    _dir.dispose();
    super.dispose();
  }

  InputDecoration _dec(String label, String hint) => InputDecoration(
        labelText: label,
        hintText: hint,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      );

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(settingsProvider);
    final c = ref.read(settingsProvider.notifier);

    return Scaffold(
      appBar: AppBar(title: const Text('Ajustes')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _Section(
                title: 'Reproductor',
                children: [
                  Text('Ocultar controles tras ${s.autoHideSeconds} s de inactividad'),
                  Slider(
                    min: 1,
                    max: 10,
                    divisions: 9,
                    value: s.autoHideSeconds.toDouble(),
                    label: '${s.autoHideSeconds} s',
                    onChanged: (v) => c.setAutoHide(v.round()),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Decodificación por hardware (HW)'),
                    subtitle: const Text('Valor por defecto al abrir un video'),
                    value: s.hardwareDecoding,
                    onChanged: c.setHardware,
                  ),
                ],
              ),
              const SizedBox(height: 14),
              _Section(
                title: 'Apariencia',
                children: [
                  SegmentedButton<AppThemeVariant>(
                    segments: AppThemeVariant.values
                        .map((v) => ButtonSegment(value: v, label: Text(v.label)))
                        .toList(),
                    selected: {s.theme},
                    onSelectionChanged: (v) => c.setTheme(v.first),
                  ),
                  if (WindowEffects.supported)
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Efecto acrílico de ventana'),
                      subtitle: const Text('Transparencia del sistema (Windows/Linux)'),
                      value: s.acrylic,
                      onChanged: c.setAcrylic,
                    ),
                ],
              ),
              const SizedBox(height: 14),
              _Section(
                title: 'Red y descargas',
                children: [
                  TextField(
                    controller: _proxy,
                    decoration: _dec('Proxy', 'http://127.0.0.1:8080 o socks5://...'),
                    onChanged: c.setProxy,
                  ),
                  const SizedBox(height: 12),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Forzar IPv4'),
                    value: s.forceIpv4,
                    onChanged: c.setForceIpv4,
                  ),
                  TextField(
                    controller: _ytdlp,
                    decoration: _dec('Ruta de yt-dlp (opcional)', 'Vacío = junto al ejecutable o PATH'),
                    onChanged: c.setYtDlpPath,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _dir,
                    decoration: _dec('Carpeta de descargas (opcional)', 'Vacío = Descargas/BytePlayer'),
                    onChanged: c.setDownloadDir,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.children});
  final String title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return GlassContainer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.bold, color: AppColors.red)),
          const SizedBox(height: 10),
          ...children,
        ],
      ),
    );
  }
}
