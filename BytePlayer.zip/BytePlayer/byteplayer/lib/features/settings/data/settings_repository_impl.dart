import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/theme/app_theme.dart';
import '../domain/entities/app_settings.dart';
import '../domain/repositories/settings_repository.dart';

class SharedPrefsSettingsRepository implements SettingsRepository {
  SharedPrefsSettingsRepository(this._prefs);
  final SharedPreferences _prefs;

  @override
  AppSettings load() {
    const d = AppSettings();
    final themeIdx = _prefs.getInt('theme') ?? d.theme.index;
    return AppSettings(
      autoHideSeconds: _prefs.getInt('autoHide') ?? d.autoHideSeconds,
      theme: AppThemeVariant.values[themeIdx.clamp(0, AppThemeVariant.values.length - 1)],
      hardwareDecoding: _prefs.getBool('hw') ?? d.hardwareDecoding,
      acrylic: _prefs.getBool('acrylic') ?? d.acrylic,
      proxy: _prefs.getString('proxy') ?? d.proxy,
      forceIpv4: _prefs.getBool('ipv4') ?? d.forceIpv4,
      ytDlpPath: _prefs.getString('ytdlp') ?? d.ytDlpPath,
      downloadDir: _prefs.getString('dlDir') ?? d.downloadDir,
    );
  }

  @override
  Future<void> save(AppSettings s) async {
    await _prefs.setInt('autoHide', s.autoHideSeconds);
    await _prefs.setInt('theme', s.theme.index);
    await _prefs.setBool('hw', s.hardwareDecoding);
    await _prefs.setBool('acrylic', s.acrylic);
    await _prefs.setString('proxy', s.proxy);
    await _prefs.setBool('ipv4', s.forceIpv4);
    await _prefs.setString('ytdlp', s.ytDlpPath);
    await _prefs.setString('dlDir', s.downloadDir);
  }
}
