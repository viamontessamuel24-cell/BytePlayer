class EqualizerPresets {
  EqualizerPresets._();

  static const frequencies = <int>[31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
  static const labels = <String>['31', '62', '125', '250', '500', '1k', '2k', '4k', '8k', '16k'];

  static const presets = <String, List<double>>{
    'Plano': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    'Bajos': [6, 5, 4, 2, 0, 0, 0, 0, 0, 0],
    'Voces': [-2, -1, 0, 2, 4, 4, 3, 1, 0, -1],
    'Rock': [5, 4, 2, -1, -2, 0, 2, 4, 5, 5],
    'Agudos': [0, 0, 0, 0, 0, 1, 3, 5, 6, 6],
  };
}
