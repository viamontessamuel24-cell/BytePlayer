import 'package:flutter/widgets.dart';

/// Contrato del motor de reproducción. La UI solo conoce esta interfaz;
/// la implementación concreta (media_kit/libmpv) vive en la capa data.
abstract class PlayerEngine {
  Stream<bool> get playingStream;
  Stream<Duration> get positionStream;
  Stream<Duration> get durationStream;
  Stream<bool> get bufferingStream;
  Stream<String> get errorStream;

  Future<void> open(String source);
  Future<void> playOrPause();
  Future<void> seek(Duration position);
  Future<void> setRate(double rate);

  /// 0..100
  Future<void> setVolume(double volume);
  Future<void> setHardwareDecoding(bool enabled);

  /// 10 ganancias en dB (-12..12), una por banda.
  Future<void> setEqualizer(List<double> gains);

  Widget buildVideo();
  Future<void> dispose();
}
