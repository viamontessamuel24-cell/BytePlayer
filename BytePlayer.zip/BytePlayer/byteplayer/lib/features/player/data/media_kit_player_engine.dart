import 'dart:async';
import 'package:flutter/material.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import '../domain/entities/equalizer_presets.dart';
import '../domain/repositories/player_engine.dart';

class MediaKitPlayerEngine implements PlayerEngine {
  MediaKitPlayerEngine({required bool hardware}) {
    _player = Player(configuration: const PlayerConfiguration(title: 'BytePlayer'));
    _controller = VideoController(
      _player,
      configuration: const VideoControllerConfiguration(enableHardwareAcceleration: true),
    );
    unawaited(setHardwareDecoding(hardware));
  }

  late final Player _player;
  late final VideoController _controller;

  @override
  Stream<bool> get playingStream => _player.stream.playing;
  @override
  Stream<Duration> get positionStream => _player.stream.position;
  @override
  Stream<Duration> get durationStream => _player.stream.duration;
  @override
  Stream<bool> get bufferingStream => _player.stream.buffering;
  @override
  Stream<String> get errorStream => _player.stream.error;

  @override
  Future<void> open(String source) => _player.open(Media(source));

  @override
  Future<void> playOrPause() => _player.playOrPause();

  @override
  Future<void> seek(Duration position) => _player.seek(position);

  @override
  Future<void> setRate(double rate) => _player.setRate(rate);

  @override
  Future<void> setVolume(double volume) => _player.setVolume(volume);

  Future<void> _setProperty(String name, String value) async {
    try {
      await (_player.platform as dynamic).setProperty(name, value);
    } catch (_) {
      // Plataforma sin acceso directo a mpv: se ignora.
    }
  }

  @override
  Future<void> setHardwareDecoding(bool enabled) =>
      _setProperty('hwdec', enabled ? 'auto-safe' : 'no');

  @override
  Future<void> setEqualizer(List<double> gains) {
    final parts = <String>[];
    for (var i = 0; i < EqualizerPresets.frequencies.length && i < gains.length; i++) {
      if (gains[i].abs() < 0.05) continue;
      parts.add('equalizer=f=${EqualizerPresets.frequencies[i]}:t=o:w=1:g=${gains[i].toStringAsFixed(1)}');
    }
    final filter = parts.isEmpty ? '' : 'lavfi=[${parts.join(',')}]';
    return _setProperty('af', filter);
  }

  @override
  Widget buildVideo() => Video(
        controller: _controller,
        controls: NoVideoControls,
        fill: Colors.black,
      );

  @override
  Future<void> dispose() => _player.dispose();
}
