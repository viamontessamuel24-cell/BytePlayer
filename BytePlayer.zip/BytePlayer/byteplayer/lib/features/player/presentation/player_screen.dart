import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/media_utils.dart';
import '../../../core/widgets/glass_container.dart';
import '../../settings/presentation/settings_controller.dart';
import '../domain/repositories/player_engine.dart';
import 'player_providers.dart';
import 'player_settings_dialog.dart';

class PlayerScreen extends ConsumerStatefulWidget {
  const PlayerScreen({
    super.key,
    required this.source,
    required this.title,
    this.isAudio = false,
  });

  final String source;
  final String title;
  final bool isAudio;

  @override
  ConsumerState<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends ConsumerState<PlayerScreen> {
  final _focus = FocusNode();
  late final PlayerEngine _engine;
  final _subs = <StreamSubscription>[];

  Timer? _hideTimer;
  bool _visible = true;
  bool _playing = true;
  Duration _position = Duration.zero;
  double _volume = 100;
  double? _drag;

  @override
  void initState() {
    super.initState();
    _engine = ref.read(playerEngineProvider);
    _subs.add(_engine.playingStream.listen((p) {
      _playing = p;
      if (!p && mounted) {
        setState(() => _visible = true); // en pausa siempre visibles
      } else {
        _poke();
      }
    }));
    _subs.add(_engine.positionStream.listen((d) => _position = d));
    _subs.add(_engine.errorStream.listen((e) {
      if (!mounted || e.isEmpty) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    }));
    _engine.open(widget.source);
    _poke();
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    for (final s in _subs) {
      s.cancel();
    }
    _focus.dispose();
    super.dispose();
  }

  /// Muestra los controles y reinicia el temporizador de autoocultado.
  void _poke() {
    if (!mounted) return;
    if (!_visible) setState(() => _visible = true);
    _hideTimer?.cancel();
    if (widget.isAudio) return;
    final secs = ref.read(settingsProvider).autoHideSeconds;
    _hideTimer = Timer(Duration(seconds: secs), () {
      if (mounted && _playing) setState(() => _visible = false);
    });
  }

  KeyEventResult _onKey(FocusNode node, KeyEvent e) {
    if (e is! KeyDownEvent) return KeyEventResult.ignored;
    final k = e.logicalKey;
    if (k == LogicalKeyboardKey.space) {
      _engine.playOrPause();
    } else if (k == LogicalKeyboardKey.arrowRight) {
      _engine.seek(_position + const Duration(seconds: 5));
    } else if (k == LogicalKeyboardKey.arrowLeft) {
      final t = _position - const Duration(seconds: 5);
      _engine.seek(t < Duration.zero ? Duration.zero : t);
    } else if (k == LogicalKeyboardKey.escape) {
      Navigator.of(context).maybePop();
    } else {
      return KeyEventResult.ignored;
    }
    _poke();
    return KeyEventResult.handled;
  }

  void _openSettings() {
    _hideTimer?.cancel();
    showDialog<void>(
      context: context,
      barrierColor: Colors.black54,
      builder: (_) => const PlayerSettingsDialog(),
    ).then((_) => _poke());
  }

  Widget _fade(Widget child) => AnimatedOpacity(
        opacity: _visible ? 1 : 0,
        duration: const Duration(milliseconds: 250),
        child: IgnorePointer(ignoring: !_visible, child: child),
      );

  @override
  Widget build(BuildContext context) {
    ref.watch(playerEngineProvider); // mantiene vivo el motor mientras la pantalla exista

    return Scaffold(
      backgroundColor: Colors.black,
      body: Focus(
        focusNode: _focus,
        autofocus: true,
        onKeyEvent: _onKey,
        child: MouseRegion(
          cursor: _visible ? SystemMouseCursors.basic : SystemMouseCursors.none,
          onHover: (_) => _poke(),
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => _visible ? setState(() => _visible = false) : _poke(),
            onDoubleTap: () {
              _engine.playOrPause();
              _poke();
            },
            child: Stack(
              fit: StackFit.expand,
              children: [
                Positioned.fill(
                  child: widget.isAudio ? _AudioBackdrop(title: widget.title) : _engine.buildVideo(),
                ),
                Positioned(top: 0, left: 0, right: 0, child: _fade(_topBar())),
                Positioned(left: 0, right: 0, bottom: 0, child: _fade(_bottomBar())),
                StreamBuilder<bool>(
                  stream: _engine.bufferingStream,
                  builder: (_, s) => (s.data ?? false)
                      ? const Center(child: CircularProgressIndicator(color: AppColors.red))
                      : const SizedBox.shrink(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _topBar() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: GlassContainer(
          borderRadius: 20,
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                onPressed: () => Navigator.of(context).maybePop(),
              ),
              Expanded(
                child: Text(
                  widget.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.tune_rounded, color: Colors.white),
                tooltip: 'Ajustes del reproductor',
                onPressed: _openSettings,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _bottomBar() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: GlassContainer(
          glow: true,
          borderRadius: 26,
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _seekBar(),
              Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.replay_10_rounded, color: Colors.white),
                    onPressed: () {
                      final t = _position - const Duration(seconds: 10);
                      _engine.seek(t < Duration.zero ? Duration.zero : t);
                      _poke();
                    },
                  ),
                  _playButton(),
                  IconButton(
                    icon: const Icon(Icons.forward_10_rounded, color: Colors.white),
                    onPressed: () {
                      _engine.seek(_position + const Duration(seconds: 10));
                      _poke();
                    },
                  ),
                  const Spacer(),
                  Icon(_volume == 0 ? Icons.volume_off_rounded : Icons.volume_up_rounded,
                      color: Colors.white, size: 20),
                  SizedBox(
                    width: 110,
                    child: Slider(
                      min: 0,
                      max: 100,
                      value: _volume,
                      onChanged: (v) {
                        setState(() => _volume = v);
                        _engine.setVolume(v);
                        _poke();
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _playButton() {
    return StreamBuilder<bool>(
      stream: _engine.playingStream,
      initialData: true,
      builder: (_, s) {
        final playing = s.data ?? true;
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 6),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(colors: [AppColors.red, AppColors.redDark]),
            boxShadow: [BoxShadow(color: AppColors.red.withOpacity(0.6), blurRadius: 22)],
          ),
          child: IconButton(
            iconSize: 34,
            icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white),
            onPressed: () {
              _engine.playOrPause();
              _poke();
            },
          ),
        );
      },
    );
  }

  Widget _seekBar() {
    return StreamBuilder<Duration>(
      stream: _engine.durationStream,
      initialData: Duration.zero,
      builder: (_, dSnap) {
        final total = dSnap.data ?? Duration.zero;
        return StreamBuilder<Duration>(
          stream: _engine.positionStream,
          initialData: Duration.zero,
          builder: (_, pSnap) {
            final pos = pSnap.data ?? Duration.zero;
            final max = total.inMilliseconds.toDouble();
            final value = (_drag ?? pos.inMilliseconds.toDouble()).clamp(0.0, max > 0 ? max : 1.0);
            return Row(
              children: [
                Text(formatDuration(Duration(milliseconds: value.toInt())),
                    style: const TextStyle(color: Colors.white, fontSize: 12)),
                Expanded(
                  child: Slider(
                    min: 0,
                    max: max > 0 ? max : 1.0,
                    value: value,
                    onChanged: max > 0
                        ? (v) {
                            setState(() => _drag = v);
                            _poke();
                          }
                        : null,
                    onChangeEnd: (v) {
                      _engine.seek(Duration(milliseconds: v.toInt()));
                      setState(() => _drag = null);
                    },
                  ),
                ),
                Text(formatDuration(total), style: const TextStyle(color: Colors.white, fontSize: 12)),
              ],
            );
          },
        );
      },
    );
  }
}

class _AudioBackdrop extends StatelessWidget {
  const _AudioBackdrop({required this.title});
  final String title;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          center: Alignment(0, -0.2),
          radius: 1.0,
          colors: [Color(0xFF3A0A10), AppColors.bg],
        ),
      ),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 160,
              height: 160,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const LinearGradient(colors: [AppColors.red, AppColors.redDark]),
                boxShadow: [BoxShadow(color: AppColors.red.withOpacity(0.5), blurRadius: 50, spreadRadius: 4)],
              ),
              child: const Icon(Icons.music_note_rounded, size: 84, color: Colors.white),
            ),
            const SizedBox(height: 28),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Text(title,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w600)),
            ),
          ],
        ),
      ),
    );
  }
}
