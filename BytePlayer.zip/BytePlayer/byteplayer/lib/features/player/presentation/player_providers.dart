import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../settings/presentation/settings_controller.dart';
import '../data/media_kit_player_engine.dart';
import '../domain/entities/equalizer_presets.dart';
import '../domain/repositories/player_engine.dart';

final playerEngineProvider = Provider.autoDispose<PlayerEngine>((ref) {
  final hw = ref.read(settingsProvider).hardwareDecoding;
  final engine = MediaKitPlayerEngine(hardware: hw);
  ref.onDispose(engine.dispose);
  return engine;
});

class PlayerSettingsState {
  const PlayerSettingsState({required this.rate, required this.hardware, required this.gains});

  final double rate;
  final bool hardware;
  final List<double> gains;

  PlayerSettingsState copyWith({double? rate, bool? hardware, List<double>? gains}) =>
      PlayerSettingsState(
        rate: rate ?? this.rate,
        hardware: hardware ?? this.hardware,
        gains: gains ?? this.gains,
      );
}

final playerSettingsProvider =
    AutoDisposeNotifierProvider<PlayerSettingsController, PlayerSettingsState>(
        PlayerSettingsController.new);

class PlayerSettingsController extends AutoDisposeNotifier<PlayerSettingsState> {
  PlayerEngine get _engine => ref.read(playerEngineProvider);

  @override
  PlayerSettingsState build() => PlayerSettingsState(
        rate: 1.0,
        hardware: ref.read(settingsProvider).hardwareDecoding,
        gains: List<double>.filled(EqualizerPresets.frequencies.length, 0),
      );

  Future<void> setRate(double rate) async {
    state = state.copyWith(rate: rate);
    await _engine.setRate(rate);
  }

  Future<void> setHardware(bool hw) async {
    state = state.copyWith(hardware: hw);
    await _engine.setHardwareDecoding(hw);
  }

  /// Actualiza la UI mientras se arrastra (sin tocar el motor).
  void setBandLocal(int index, double gain) {
    final g = List<double>.from(state.gains)..[index] = gain;
    state = state.copyWith(gains: g);
  }

  /// Aplica el ecualizador al motor (al soltar el slider).
  Future<void> applyEqualizer() => _engine.setEqualizer(state.gains);

  Future<void> applyPreset(List<double> gains) async {
    state = state.copyWith(gains: List<double>.from(gains));
    await _engine.setEqualizer(state.gains);
  }
}
