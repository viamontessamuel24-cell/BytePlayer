import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/widgets/glass_container.dart';
import '../domain/entities/equalizer_presets.dart';
import 'player_providers.dart';

class PlayerSettingsDialog extends ConsumerWidget {
  const PlayerSettingsDialog({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final st = ref.watch(playerSettingsProvider);
    final c = ref.read(playerSettingsProvider.notifier);
    final theme = Theme.of(context);

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(16),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 640),
        child: GlassContainer(
          glow: true,
          blur: 30,
          padding: const EdgeInsets.all(20),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text('Ajustes del reproductor',
                        style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),
                const SizedBox(height: 8),

                // Velocidad
                Text('Velocidad: ${st.rate.toStringAsFixed(2)}x'),
                Slider(
                  min: 0.25,
                  max: 2.0,
                  divisions: 7,
                  value: st.rate,
                  label: '${st.rate.toStringAsFixed(2)}x',
                  onChanged: c.setRate,
                ),
                Wrap(
                  spacing: 8,
                  children: [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]
                      .map((r) => ChoiceChip(
                            label: Text('${r}x'),
                            selected: st.rate == r,
                            onSelected: (_) => c.setRate(r),
                          ))
                      .toList(),
                ),
                const SizedBox(height: 16),

                // Render HW / SW
                const Text('Decodificación'),
                const SizedBox(height: 6),
                SegmentedButton<bool>(
                  segments: const [
                    ButtonSegment(value: true, label: Text('Hardware (HW)'), icon: Icon(Icons.memory)),
                    ButtonSegment(value: false, label: Text('Software (SW)'), icon: Icon(Icons.developer_board)),
                  ],
                  selected: {st.hardware},
                  onSelectionChanged: (v) => c.setHardware(v.first),
                ),
                const SizedBox(height: 16),

                // Ecualizador
                Row(
                  children: [
                    const Text('Ecualizador (10 bandas)'),
                    const Spacer(),
                    PopupMenuButton<String>(
                      icon: const Icon(Icons.auto_awesome),
                      tooltip: 'Presets',
                      onSelected: (k) => c.applyPreset(EqualizerPresets.presets[k]!),
                      itemBuilder: (_) => EqualizerPresets.presets.keys
                          .map((k) => PopupMenuItem(value: k, child: Text(k)))
                          .toList(),
                    ),
                  ],
                ),
                SizedBox(
                  height: 200,
                  child: Row(
                    children: [
                      for (var i = 0; i < EqualizerPresets.frequencies.length; i++)
                        Expanded(
                          child: Column(
                            children: [
                              Text('${st.gains[i].round()}', style: const TextStyle(fontSize: 10)),
                              Expanded(
                                child: RotatedBox(
                                  quarterTurns: 3,
                                  child: Slider(
                                    min: -12,
                                    max: 12,
                                    value: st.gains[i],
                                    onChanged: (v) => c.setBandLocal(i, v),
                                    onChangeEnd: (_) => c.applyEqualizer(),
                                  ),
                                ),
                              ),
                              Text(EqualizerPresets.labels[i], style: const TextStyle(fontSize: 10)),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
