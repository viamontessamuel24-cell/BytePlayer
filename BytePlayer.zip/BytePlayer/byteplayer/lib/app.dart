import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/constants/app_constants.dart';
import 'core/theme/app_theme.dart';
import 'core/widgets/app_background.dart';
import 'features/home/presentation/home_screen.dart';
import 'features/settings/presentation/settings_controller.dart';

class BytePlayerApp extends ConsumerWidget {
  const BytePlayerApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final variant = ref.watch(settingsProvider.select((s) => s.theme));
    return MaterialApp(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.build(variant),
      builder: (context, child) => AppBackground(child: child ?? const SizedBox.shrink()),
      home: const HomeScreen(),
    );
  }
}
